﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;


namespace ConnectedWPFApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        EmployeeDAL objEmployeeDAL;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            objEmployeeDAL = new EmployeeDAL();
            GetDepartment();
            GetDesignation();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            InsertEmployee();

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            UpdateEmployee();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            DeleteEmployee();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchEmployee();
        }

        private void BtnGetList_Click(object sender, RoutedEventArgs e)
        {
            GetEmployee();//modularity
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void InsertEmployee()
        {
            
            int id;
            string name;
            int designation;
            int department;

            id = Convert.ToInt32(TxtID.Text);
            name = TxtName.Text;
            designation = Convert.ToInt32(CbDesignation.SelectedValue);
            department= Convert.ToInt32(CbDepartment.SelectedValue);

            Employee objEmployee = new Employee();
            objEmployee.id = id;
            objEmployee.Name = name;
            objEmployee.Designation = designation;
            objEmployee.Department = department;

            bool dataAdded = objEmployeeDAL.InsertEmployee(objEmployee);
            if(dataAdded == true)
            {
                MessageBox.Show("Data Added Successfully");

            }
            else
            {
                MessageBox.Show("Data couldn't be Added");
            }


        }
        private void UpdateEmployee()
        {
            int id;
            string name;
            int designation;
            int department;

            id = Convert.ToInt32(TxtID.Text);
            name = TxtName.Text;
            designation = Convert.ToInt32(CbDesignation.SelectedValue);
            department = Convert.ToInt32(CbDepartment.SelectedValue);

            Employee objEmployee = new Employee();
            objEmployee.id = id;
            objEmployee.Name = name;
            objEmployee.Designation = designation;
            objEmployee.Department = department;

            bool dataUpdated = objEmployeeDAL.UpdateEmployee(objEmployee);
            if (dataUpdated == true)
            {
                MessageBox.Show("Data Updated Successfully");

            }
            else
            {
                MessageBox.Show("Data couldn't be Updated");
            }
        }
        private void DeleteEmployee()
        {
            int id;
            id = Convert.ToInt32(TxtID.Text);
            bool dataDeleted= objEmployeeDAL.DeleteEmployee(id);
            if(dataDeleted==true)
            {
                MessageBox.Show("Data deleted Successfully");
            }
            else
            {
                MessageBox.Show("Data couldn't be deleted");
            }
        }
        private void SearchEmployee()
        {
            int id;
            id = Convert.ToInt32(TxtID.Text);
            Employee objEmployee = objEmployeeDAL.SearchEmployee(id);
            if(objEmployee != null)
            {
                TxtName.Text = objEmployee.Name;
                CbDepartment.SelectedValue = objEmployee.Department;
                CbDesignation.SelectedValue = objEmployee.Designation;
            }
            else
            {
                MessageBox.Show("Data not found for the given id");
            }




        }
        private void GetEmployee()
        {
            DataTable objDT = objEmployeeDAL.GetEmployee();
            dgEmployeeDetails.ItemsSource = objDT.DefaultView;

        }
        private void GetDepartment()
        {
            DataTable objDT = objEmployeeDAL.GetDepartments();
            CbDepartment.ItemsSource = objDT.DefaultView;
            CbDepartment.DisplayMemberPath = objDT.Columns[1].ToString();
            CbDepartment.SelectedValuePath = objDT.Columns[0].ToString();
        }
        private void GetDesignation()
        {
            DataTable objDT = objEmployeeDAL.GetDesignations();
            CbDesignation.ItemsSource = objDT.DefaultView;
            CbDesignation.DisplayMemberPath = objDT.Columns[1].ToString();// to display the name
            CbDesignation.SelectedValuePath = objDT.Columns[0].ToString();// to display the value of the selected mem
        }
        private void Clear()
        {
            TxtID.Clear();
            TxtName.Clear();
            CbDepartment.SelectedIndex = -1;
            CbDesignation.SelectedIndex = -1;
        }
    }
}
