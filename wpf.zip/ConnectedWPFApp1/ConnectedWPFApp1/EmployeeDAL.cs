﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ConnectedWPFApp1
{
    class EmployeeDAL
    {
       
        public bool InsertEmployee(Employee objEmployee)
        {
            bool dataInserted = false;

            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand("Insert into [46008167].[Employee] values(" + objEmployee.id + ", '" + objEmployee.Name + "', "
                                           + objEmployee.Designation + ", "+objEmployee.Department+ ")" ,objCon);
            objCon.Open();
            int noOfRowsAffected = objCom.ExecuteNonQuery();
            if(noOfRowsAffected>0)
            {
                dataInserted = true;
            }

            objCon.Close();
            return dataInserted;

        }


        public bool UpdateEmployee(Employee objEmployee)
        {
            bool dataUpdated = false;

            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
           


            SqlCommand objCom = new SqlCommand("Update [46008167].[Employee] set name='" + objEmployee.Name +
                                                 "', designation=" + objEmployee.Designation + " ,  department="
                                                 + objEmployee.Department + " where id=" + objEmployee.id, objCon);
            objCon.Open();
            int noOfRowsAffected = objCom.ExecuteNonQuery();
            if (noOfRowsAffected > 0)
            {
                dataUpdated = true;
            }

            objCon.Close();
            return dataUpdated;
         
        }


        public bool DeleteEmployee(int id)
        {

            bool dataDeleted = false;

            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand("Delete  [46008167].[Employee] where id=" + id, objCon);
            objCon.Open();
            int noOfRowsAffected = objCom.ExecuteNonQuery();
            if (noOfRowsAffected > 0)
            {
                dataDeleted = true;
            }

            objCon.Close();
            return dataDeleted;

        }


        public Employee SearchEmployee(int id)
        {
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand("Select * from  [46008167].[Employee] where id=" + id, objCon);
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader(); // acts as a collection class
            Employee objEmployee = null;
            if (objDR.HasRows)
            {
                objDR.Read();
                objEmployee = new Employee();
                objEmployee.id = Convert.ToInt32(objDR[0]);
                objEmployee.Name = objDR[1].ToString();
                objEmployee.Designation = Convert.ToInt32(objDR[2]);
                objEmployee.Department = Convert.ToInt32(objDR[3]);
               
            }
            return objEmployee;

        }

        public DataTable GetEmployee()
        {
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand("Select * from [46008167].[Employee] ", objCon);
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader(); // acts as a collection class
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            objCon.Close();
            return objDT;
        }
        public DataTable GetDesignations()
        {
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand("Select * from [46008167].[DesignationDetails]", objCon);
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader(); 
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            objCon.Close();
            return objDT;
        }
        public DataTable GetDepartments()
        {
            SqlConnection objCon = new SqlConnection(@"server=ndamssql\sqlilearn;database=Training_19Sep19_Pune; uid=sqluser;pwd=sqluser");
            SqlCommand objCom = new SqlCommand("Select * from [46008167].[DepartmentDetails]", objCon);
            objCon.Open();
            SqlDataReader objDR = objCom.ExecuteReader(); 
            DataTable objDT = new DataTable();
            objDT.Load(objDR);
            objCon.Close();
            return objDT;
        }
    }
    
}
