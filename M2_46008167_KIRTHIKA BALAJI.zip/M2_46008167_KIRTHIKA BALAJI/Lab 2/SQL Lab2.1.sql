use training_19sep19_pune

go


--List the empno, name and Department No of the employees who have got experience of more than 18 years.

select empno, ename, deptno 
from emp
where datediff(year,hiredate,getdate()) > 18

--------------------------------------------------------------------------

--Display the name and salary of the staff. Salary should be represented as X. 

select Staff_Name, Replicate('X',Salary/1000) as Salary
from Staff_Master

----------------------------------------------------------------------------------
--List out all the book code and library member codes whose return is still pending

select Book_Code,Coalesce(Staff_Code,Stud_Code) as Member_Code
from Book_Transaction b
where b.Actual_Return_date is null;

------------------------------------------------------------------------------------

--List all the staff�s whose birthday falls on the current month

select * 
from Staff_Master
where datepart(month,Staff_dob) = datepart(month,getdate());

-------------------------------------------------------------------------------------

--How many books are stocked in the library?

select count(Book_Code) as 'Number of Books in Library'
from Book_Master


-------------------------------------------------------------------------------------
--How many books are there for topics Physics and Chemistry?

select count(Book_Code) as 'Physics and Chemistry Books'
from Book_Master
group by Book_category
having book_Category='Physics' or book_Category='Chemistry'

--------------------------------------------------------------------------------------
--How many members are expected to return their books today?

select count(Book_Code) as 'Books expected today'
from Book_Transaction
where Exp_Return_date = getdate();

--------------------------------------------------------------------------------------

--Display the Highest, Lowest, Total & Average salary of all staff. Label the columns
--Maximum, Minimum, Total and Average respectively. Round the result to nearest
--whole number

select ceiling(max(Salary)) as 'Maximum', ceiling(min(Salary)) as 'Minimum',
ceiling(sum(Salary)) as 'Total' ,ceiling(avg(Salary)) as 'Average'
from Staff_Master

---------------------------------------------------------------------------------------

--How many staffs are manager?

select count(distinct Mgr_code) as 'Number of Managers' 
from Staff_Master

----------------------------------------------------------------------------------------

--List out year wise total students passed. The report should be as given below. A
--student is considered to be passed only when he scores 60 and above in all 3
--subjects individually

select distinct stud_year as 'Year',count(Stud_Code) 'No of students passed'
from Student_Marks
where Subject1>=60 and Subject2>=60 and Subject3>=60
group by stud_year

----------------------------------------------------------------------------------------

--List out all the departments which is having a headcount of more than 10

select distinct d.Dept_Code as Code, d.Dept_Name as 'Department Name'
from Department_master d,Student_Master s
where s.Dept_Code = d.Dept_Code and d.Dept_Code in (select Dept_Code from Student_Master group by Dept_Code having count(Dept_Code)>10 )
order by d.Dept_Code



---------------------------------------------------------------------------------------

--How many students have joined in Physics dept (dept code is 10) last year?

select count(a.Stud_Code) as 'Number of students who joined in Physics dept in 2019'
from Student_Master a,Student_Marks b
where a.Stud_Code =b.Stud_Code
and b.Stud_Year = 2019 and a.Dept_Code = 10;



