use training_19sep19_pune

go


--Create a Filtered Index HumanResources.


CREATE NONCLUSTERED INDEX NCI_Department
ON HumanResources.Employee(EmployeeID)
WHERE Title= 'Marketing Manager'

--------------------------------------------------------------------------------------