USE [Training_19Sep19_Pune]
GO


--Write a procedure that accept Staff_Code and updates the salary 

select * into .Staff_Master_Back_46008167 from Staff_Master;



select * from Staff_Master_Back_46008167;

create procedure Update_Salary_46008167 @Staff_Code_in numeric(8,0)
as 
declare @Sal numeric(10,2)
update Staff_Master_Back_46008167
set @Sal = ( case
					when datediff(year,Hiredate,getdate()) < 2 then Salary
					when datediff(year,Hiredate,getdate()) >= 2 and datediff(year,Hiredate,getdate()) <=5 then Salary*1.20
					when datediff(year,Hiredate,getdate()) > 5 then Salary*1.25
				end),
Staff_Master_Back_46008167.Salary = @Sal 
where Staff_Code=@Staff_Code_in
return @Sal
go

declare @Sal_Updated numeric(10,2);
exec @Sal_Updated=Update_Salary_46008167 @Staff_Code_in = 100005;  
select @Sal_Updated;

------------------------------------------------------------------------------------------------------------------------------
--Write a procedure to insert details into Book_Transaction table. 


select * into Book_Transaction_46008167 from Book_Transaction;

create procedure Issue_Book_46008167@Book_Code numeric(10,0), @Staff_Code_in numeric(8,0), @Student_Code_in numeric(6,0)
as 
declare @Issue_date datetime, @Exp_Return_date datetime,
set @Issue_date = getdate()
set @Exp_Return_date = @Issue_date+10
if datepart(dw,@Exp_Return_date) in (6,7)
set @Exp_Return_date = 1
begin try
insert into Book_Transaction_46008167
values (@Book_Code, @Staff_Code_in,@Student_Code_in,@Issue_date,@Exp_Return_date,NULL);
end try
begin catch
	select error_message() as ErrorMessage;  
end catch
go

select * from Book_Transaction_46008167

exec Issue_Book_46008167 @Book_Code=10000005,@Staff_Code_in=100006,@Student_Code_in=NULL;

-------------------------------------------------------------------------------------------------------------------------------
--Modify question 1 and display the results by specifying With result sets


select * into Staff_Master_Back_46008167 from Staff_Master;

drop table Staff_Master_Back_46008167;

create procedure Update_Salary_46008167_New @Staff_Code_in numeric(8,0)
as 
declare @Sal numeric(10,2)
update Staff_Master_Back_46008167 
set @Sal = ( case
					when datediff(year,Hiredate,getdate()) < 2 then Salary
					when datediff(year,Hiredate,getdate()) >= 2 and datediff(year,Hiredate,getdate()) <=5 then Salary*1.20
					when datediff(year,Hiredate,getdate()) > 5 then Salary*1.25
				end),
Staff_Master_Back_46008167.Salary = @Sal 
where Staff_Code=@Staff_Code_in
begin
select @Sal
end 
go

drop procedure Update_Salary_46008167_New
exec Update_Salary_46008167_New @Staff_Code_in = 100005
with result sets
(([Salary] numeric(10,2)));  

----------------------------------------------------------------------------------------------------------------------------------
--Create a procedure that accepts the book code as parameter from the user. Display
--the details of the students/staff that have borrowed that book and has not returned
--the same.

create procedure Not_Returned_Book_46008167 @Book_Code_in numeric(10,0)
as

select s.Staff_Code,Staff_Name, Issue_date, c.Design_Name, Exp_Return_Date
from Staff_Master s,Book_Transaction b,Desig_master c
where s.Staff_Code = b.Staff_Code and s.Des_Code = c.Design_Code
and s.Staff_Code in (select Staff_Code from Book_transaction b where b.Book_Code=@Book_Code_in)
select s.Stud_Code,Stud_Name, Issue_date, Exp_Return_Date
from Student_Master s,Book_Transaction b 
where s.Stud_Code = b.Stud_Code
and s.Stud_Code in (select Stud_Code from Book_transaction b where b.Book_Code=@Book_Code_in)
 

go

drop procedure Not_Returned_Book_46008167


exec Not_Returned_Book_46008167 @Book_Code_in = 10000001;

-----------------------------------------------------------------------------------------------------------------------------------

--Write a procedure to update the marks details in the Student_marks table

select * into Student_Marks_46008167 from Student_Marks;
select * into Student_Master_46008167from Student_Master;

insert into Student_Master_46008167 values (1022,'Aritra',30,getdate(),'Pune');

select * from Student_Master_46008167

create procedure Insert_Student_Marks_46008167 @Stud_Code_in numeric(6,0), 
@Subject1_in numeric(3,0), @Subject2_in numeric(3,0),@Subject3_in numeric(3,0)
as
declare @Year int
set @Year = datepart(year,getdate());
begin try
if @Stud_Code_in is null 
begin
	return -1
end
if not exists(select Stud_code from Student_Master_46008167 s where s.Stud_Code=@Stud_Code_in)
begin
	return -1
end
if exists (select Stud_code from Student_Marks_46008167 s where s.Stud_Code=@Stud_Code_in)
begin
	return -1
end
else
begin
	insert into Student_Marks_46008167 values (@Stud_Code_in,@Year,@Subject1_in,@Subject2_in,@Subject3_in)
	return 0
end
end try

begin catch
	select error_message() as ErrorMessage
	return -1
end catch
go

drop procedure Insert_Student_Marks_46008167

declare @ret int;
exec @ret=Insert_Student_Marks_46008167 @Stud_Code_in = 1022, @Subject1_in = 75, @Subject2_in = 75,@Subject3_in = 75;

select @ret;
select * from Student_Marks_46008167;

------------------------------------------------------------------------------------------------------------------------------------------