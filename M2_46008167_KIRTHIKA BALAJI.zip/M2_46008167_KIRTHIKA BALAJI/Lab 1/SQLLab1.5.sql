USE [Training_19Sep19_Pune]
GO

--Write a query which displays Staff Name, Department Code, Department Name, and
--Salary for all staff who earns more than 20000.

select a.staff_name,a.dept_code,b.dept_name,a.salary
from staff_master a inner join department_master b
on a.dept_code=b.dept_code
where a.Salary>20000

------------------------------------------------------------------------------------------
--Write a query to display Staff Name, Department Code, and Department Name for all
--staff who do not work in Department code 10

select a.Staff_Name,a.Dept_Code,b.Dept_Name,a.salary
from staff_master a inner join department_master b
on a.dept_code=b.dept_code
where a.dept_code <> 10

-------------------------------------------------------------------------------------------
--Print out a report like this
--Book Name No of times issued

select a.Book_name, Count(b.Book_Code) as 'No of times issued'
from Book_Master a inner join Book_Transaction b
on a.Book_code = b.Book_code 
group by a.Book_name

--------------------------------------------------------------------------------------------
--List out number of students joined each department last year. The report should be
--displayed like this

--Data not provided

--List out a report like this
--Staff Code Staff Name Manager Code Manager Name

select a.Staff_Code,a.Staff_Name,a.Mgr_Code,b.Staff_Name as "Manager Name"
from Staff_Master a inner join Staff_Master b
on a.Mgr_Code=b.Staff_Code

---------------------------------------------------------------------------------------------
--Display the Staff Name, Hire date and day of the week on which staff was hired.
--Label the column as DAY. Order the result by the day of the week starting with
--Monday.

set datefirst 1;
select Staff_Name, Hiredate, Datename(dw,Hiredate) as DAY
from Staff_Master
order by DatePart(dw,Hiredate)

--To set the datefirst back to sunday
set datefirst 7;


---------------------------------------------------------------------------------------------
--Display Staff Code, Staff Name, and Department Name for those who have taken
--more than one book.

select distinct a.Staff_Code,Staff_Name,Dept_Name
from Book_Transaction a inner join Staff_Master b
on  a.Staff_code = b.Staff_Code
inner join Department_Master c
on b.Dept_Code = c.Dept_Code
where a.Staff_code in (select Staff_code from Book_Transaction group by Staff_Code having count(Staff_code)>1)

---------------------------------------------------------------------------------------------------------------
--List out the names of all student code whose score in subject1 is equal to the
--highest score

select a.Stud_Code
from Student_Master a inner join Student_Marks b
on a.Stud_Code = b.Stud_Code 
where b.Subject1 = (select max(Subject1) from Student_Marks ) 

--------------------------------------------------------------------------------------------------
--Modify the above query to display student names along with the codes

select a.Stud_Code,a.Stud_Name
from Student_Master a inner join Student_Marks b
on a.Stud_Code = b.Stud_Code 
where b.Subject1 = (select max(Subject1) from Student_Marks ) 

--------------------------------------------------------------------------------------------------
--List out the names of all the books along with the author name, book code and
--category which have not been issued at all. Try solving this question using EXISTS.

select Book_name,Author,Book_code,Book_category
from Book_Master 
where not exists (select Book_code from Book_Transaction where Book_Transaction.Book_Code = Book_Master.Book_Code)

--------------------------------------------------------------------------------------------------
--List out the code and names of all staff and students belonging to department 20

select Stud_Code,Stud_Name
from Student_Master
where Dept_Code = 20
union
select Staff_Code,Staff_Name
from Staff_Master
where Dept_Code = 20

----------------------------------------------------------------------------------------------------------
--List out all the students who have not appeared for exams this year.

select * 
from Student_Master
where Stud_Code not in (select Stud_Code from Student_Marks)

-----------------------------------------------------------------------------------------------------------
--List out all the student codes who have never taken books

select *
from Student_Master s
where not exists (select b.Stud_code from Book_Transaction b where b.Stud_Code = s.Stud_Code)

----------------------------Customer Table------------------------------------------------
------------------------------------------------------------------------------------------



create table [46008167].Customers
(
Customerid varchar(10) unique not null, 
CustomerName varchar(35) Not Null,
Address1 varchar(30),
Address2 varchar(30),
ContactNumber varchar(12) Not Null,
PostalCode varchar(10)
);

------------------------------------------------------------------------------------------------
--create type Region from char(15)

alter table [46008167].Customers
add Customer_Region [46008167].Region;

create default defaultdemoexp as 'NA';  

alter table [46008167].Customers
add Gender char(1);

alter table [46008167].Customers
add Constraint CHK_Gender_46008167 check (Gender = 'M' or Gender = 'F' or Gender = 'T');

select * from [46008167].Customers
truncate table [46008167].Customers;

------------------------------------------------------------------------------------------------
--Add the following records to the Customers Table , created in our earlier exercises

insert into [46008167].Customers values ('ALFKI','AlfredsFutterkiste','Obere Str. 57','Berlin,Germany','030-0074321','12209',NULL,NULL)

insert into [46008167].Customers values ('ANATR','Ana Trujillo Emparedadosy helados','Avda. de la Constituci �n 2222','M�xico D.F.,Mexico','(5) 555-4729','5021','NA',NULL)

insert into [46008167].Customers values ('ANTON','Antonio Moreno Taquer�a','Matadero s 2312','M�xico D.F.,Mexico','(5) 555-3932','5023',NULL,NULL)

insert into [46008167].Customers values ('AROUT','Around the Horn','120 Hanover Sq.','London,UK','(171)5557788','WA11DP',NULL,NULL)

insert into [46008167].Customers values ('BERGS','Berglundssnabbk�p','Berguvsv�gen 8','Lule�,Sweden','0921-1234 65','S-95822',NULL,NULL)

insert into [46008167].Customers values ('BLAUS','Blauer See Delikatessen','Forsterstr. 57','Mannheim,Germany','0621-08460','68306','NA',NULL)

insert into [46008167].Customers values ('BLONP','Blondesddslp�re et fils','24, place Kl�ber','Strasbourg,France','88.60.15.31','67000',NULL,NULL)

insert into [46008167].Customers values ('BOLID','B�lidoComidaspre paradas','C/Araquil, 67','Madrid,Spain','(91)5552282','28023','EU',NULL)

insert into [46008167].Customers values ('BONAP','Bon app','12, rue des Bouchers','Marseille,France','91.24.45.40','13008',NULL,NULL)

insert into [46008167].Customersvalues ('BOTTM','Bottom-Dollar Markets','23 Tsawassen Blvd.','Tsawassen,Canada','(604)5554729','T2F8M4','BC',NULL)

----------------------------------------------------------------------------------------------------------------------
--Replace the contact number of Customer id ANATR to (604) 3332345

update [46008167].Customers
set ContactNumber='(604)3332345'
where Customerid = 'ANATR'

------------------------------------------------------------------------------------------------------------------------
--Update the Address and Region of Customer BOTTM to the following

update [46008167].Customers
set Address1='19/2 12th Block, Spring Fields',Address2 = 'Ireland - UK',Customer_Region='EU'
where Customerid = 'BOTTM'

----------------------------Orders Table--------------------------------------------------
------------------------------------------------------------------------------------------

create table [46008167].OrdersTable
(
OrdersID int not null identity(10000,1), 
CustomerId varchar(10) not null,
OrdersDate Datetime,
Order_State char(1) constraint CHK_Order_State_New check (Order_State='P' or Order_State='C'),
)



alter table [46008167].OrdersTable
add Constraint fk_CustOrders foreign key ([CustomerId]) references  [46008167].Customers ([CustomerId]) on delete cascade on update cascade;


insert into [46008167].OrdersTable values('AROUT',Datefromparts(1996,07,04),'P');
insert into [46008167].OrdersTable values('ALFKI',Datefromparts(1996,07,05),'C');
insert into [46008167].OrdersTable values('BLONP',Datefromparts(1996,07,08),'P');
insert into [46008167].OrdersTable values('ANTON',Datefromparts(1996,07,08),'P');
insert into [46008167].OrdersTable values('ANTON',Datefromparts(1996,07,09),'P');
insert into [46008167].OrdersTable values('BOTTM',Datefromparts(1996,07,10),'C');
insert into [46008167].OrdersTable values('BONAP',Datefromparts(1996,07,11),'P');
insert into [46008167].OrdersTable values('ANATR',Datefromparts(1996,07,12),'P');
insert into [46008167].OrdersTable values('BLAUS',Datefromparts(1996,07,15),'C');
insert into [46008167].OrdersTable values('HILAA',Datefromparts(1996,07,16),'P'); -----CANNOT ENTER THIS VALUE AS THIS IS ABSENT IN CUSTOMERS TABLE

select * from [46008167].OrdersTable

--------------------------------------------------------------------------------------------------------
--Delete all the Customers whose Orders have been cleared.

delete from [46008167].Customers where [46008167].Customers.Customerid in (select [46008167].OrdersTable_New.CustomerId from [46008167].OrdersTable where [46008167].OrdersTable_New.Order_State = 'C')

-------------------------------------------------------------------------------------------------------
--Remove all the records from the table using the truncate command. Rerun the script
--to populate the records once again

truncate table [46008167].OrdersTable;

--------------------------------------------------------------------------------------------------------
--Change the order status to C, for all orders before `15th July.

update [46008167].OrdersTable set Order_State='C' where OrdersDate < Datefromparts(1996,07,15);

