use training_19sep19_pune

go


create table [46008167].Customer(
customerid int ,
customer_Name varchar(20),
Address1 varchar(30),
Address2 varchar(30),
contac_number varchar(12),
postalcode varchar(10)
)

---------------------------------------------------------------------------------------------------------------------------------------

create table [46008167].Employees
(
EmployeeId int not null primary key,
Name nvarchar(255) null
);

---------------------------------------------------------------------------------------------------------------------------------------
DROP TABLE [46008167].TESTRETHROW
create table [46008167].CONTRACTOR_TABLE
(
ContractorId int not null primary key,
Name nvarchar(255) null
);

---------------------------------------------------------------------------------------------------------------------------------------

create table [46008167].TESTRETHROW
(
id int primary key
);

---------------------------------------------------------------------------------------------------------------------------------------

create type [46008167].Regions FROM char(15);

---------------------------------------------------------------------------------------------------------------------------------------

create default [46008167].defaultdemo as 'NA';  

---------------------------------------------------------------------------------------------------------------------------------------

exec sp_bindefault defaultdemo, '[46008167].Regions';

---------------------------------------------------------------------------------------------------------------------------------------

alter table [46008167].Customer
add Customer_Region [46008167].Regions;

---------------------------------------------------------------------------------------------------------------------------------------

alter table [46008167].Customer
add Gender char(1);

---------------------------------------------------------------------------------------------------------------------------------------

alter table [46008167].Customer 
add Constraint CHK_Gender check (Gender = 'M' or Gender = 'F' or Gender = 'T');

---------------------------------------------------------------------------------------------------------------------------------------

create table [46008167].Ordertable
(
OrdersID int not null identity(10000,2) , 
CustomerId int not null,
OrdersDate Datetime,
Order_State char(1) constraint CHK_Order_State check (Order_State='P' or Order_State='C'),
)


---------------------------------------------------------------------------------------------------------------------------------------

alter table [46008167].Ordertable
add Constraint fk_Customer foreign key ([CustomerId]) references  [46008167].Customer ([CustomerId])

---------------------------------------------------------------------------------------------------------------------------------------
SEQUENCES
---------------------------------------------------------------------------------------------------------------------------------------

create sequence [46008167].IdSequences as int
start with 10000
increment by 1;

---------------------------------------------------------------------------------------------------------------------------------------

insert into [46008167].Employees(EmployeeId, Name) 
values (next value for [46008167].IdSequences,'Sam');

insert into [46008167].CONTRACTOR_TABLE(ContractorId, Name) 
values (next value for IdSequence_46003367,'Abhi');

select * from  [46008167].Employees;

select * from  [46008167].CONTRACTOR_TABLE;

---------------------------------------------------------------------------------------------------------------------------------------