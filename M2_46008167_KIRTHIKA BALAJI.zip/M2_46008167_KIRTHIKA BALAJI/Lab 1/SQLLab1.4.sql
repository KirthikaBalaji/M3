
use training_19sep19_pune

go

-------------------------CASE STUDY 1------------------------------

CREATE TABLE [46008167].Products
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
)

---------------------------------------------------------------------------------------------------------------------------------------
--Insert records into target table

INSERT INTO [46008167].Products
VALUES
(1,'Tea', 10.00),
(2, 'Coffee', 20.00),
(3, 'Muffin', 30.00),
(4, 'Biscuit', 40.00)

CREATE TABLE [46008167].UpdatedProducts
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
)

---------------------------------------------------------------------------------------------------------------------------------------

--Insert records into source table
INSERT INTO [46008167].UpdatedProducts
VALUES
(1, 'Tea', 10.00),
(2, 'Coffee', 25.00),
(3, 'Muffin', 35.00),
(5, 'Pizza', 60.00)

MERGE [46008167].UpdatedProducts AS TARGET
USING [46008167].UpdatedProducts AS SOURCE
ON (TARGET.ProductID = SOURCE.ProductID)
WHEN MATCHED AND TARGET.ProductName <> SOURCE.ProductName
OR TARGET.Rate <> SOURCE.Rate THEN
UPDATE SET TARGET.ProductName = SOURCE.ProductName,
TARGET.Rate = SOURCE.Rate
WHEN NOT MATCHED BY TARGET THEN
INSERT (ProductID, ProductName, Rate)
VALUES (SOURCE.ProductID, SOURCE.ProductName, SOURCE.Rate)
WHEN NOT MATCHED BY SOURCE THEN
DELETE
OUTPUT $action,
DELETED.ProductID AS TargetProductID,
DELETED.ProductName AS TargetProductName,
DELETED.Rate AS TargetRate,
INSERTED.ProductID AS SourceProductID,
INSERTED.ProductName AS SourceProductName,
INSERTED.Rate AS SourceRate;
SELECT @@ROWCOUNT;
GO

---------------------------------------------------------------------------------------------------------------------------------------

-------------------------CASE STUDY 2------------------------------


--Employee Table

CREATE TABLE [46008167].Employeetable
(
Employee_Number INT NOT NULL PRIMARY
KEY,
Employee_Name VARCHAR(30) NULL,
Salary FLOAT NULL,
Department_Number INT NULL,
Region VARCHAR(30) NULL
)

INSERT INTO [46008167].Employeetable
VALUES
(101, 'ABHI', 20000.00,1234,'PUNE'),
(102, 'SAI', 30000.00,1235,'MUMBAI'),
(103, 'DEEPU', 40000.00,1234,'THANE'),
(104, 'PRINCE', 50000.00,1236,'NASIK'),
(105, 'ANU', 30000.00,1236,'NAGPUR')

SELECT Region, Department_Number, AVG (Salary)
Average_Salary
FROM [46008167].Employeetable
GROUP BY GROUPING SETS
( (Region, Department_Number),
(Region),
(Department_Number)
)

---------------------------------------------------------------------------------------------------------------------------------------

SELECT * FROM [46008167].Employeetable


SELECT Region, Department_Number, AVG(Salary) Average_Salary
FROM [46008167].Employeetable
GROUP BY (Region), (Department_Number)
UNION
SELECT Region, Department_Number, AVG(Salary) Average_Salary 
FROM [46008167].Employeetable
GROUP BY (Region) --ERROR
UNION
SELECT Region, Department_Number, AVG (Salary) Average_Salary
FROM [46008167].Employeetable
GROUP BY (Department_Number) --ERROR

---------------------------------------------------------------------------------------------------------------------------------------