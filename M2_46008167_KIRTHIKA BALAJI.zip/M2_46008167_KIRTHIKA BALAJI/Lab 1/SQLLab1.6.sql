USE [Training_19Sep19_Pune]
GO

--Create a Unique index on Department Name for Department master Table.
create unique index dept_unid
on Department_Master(Dept_Name)
-------------------------------------------------------------------------------------------
--Try inserting the following values and observe the output 

insert into Department_Master values (100,'Home Science');
insert into Department_Master values (200,'Home Science');
insert into Department_Master values (300,NULL);
insert into Department_Master values (400,NULL);

----CANNOT INSERT THESE VALUES AS THE DATA TYPE OF DEPT_CODE is NUMERIC(2,0)
----SO CANNOT ENTER 3 DIGIT INTEGER
-----------------------------------------------------------------------------------------------
--Create a non-clustered index for Book_Trans table on the following columns
--Boo_code, Staff_name, student name, date of issue. Try adding some values.

create NonClustered index IX_Book_Transaction_Book_Code
 on Book_Transaction (Book_Code ASC) 

 
create NonClustered index IX_Book_Transaction_Staff_Code
 on Book_Transaction (Staff_Code ASC) 

 
create NonClustered index IX_Book_Transaction_Stud_Code
 on Book_Transaction (Stud_Code ASC) 

create NonClustered index IX_Book_Transaction_Issue_Date
on Book_Transaction (Issue_Date ASC)


------DO NOT HAVE STUDENT NAME AND STAFF NAME COLUMNS IN THE TABLE------
------USED STUDENT CODE AND STAFF CODE INSTEAD--------------------------

--------------------------------------------------------------------------------------------------
--List the indexes created in the previous questions, from the sysindexes table.

select
    name as Index_Name,
    type_desc  as Index_Type,
    is_unique,
    OBJECT_NAME(object_id) as Book_Transaction
from
    sys.indexes
where
    is_hypothetical = 0 and
    index_id != 0 and
    object_id = OBJECT_ID('Book_Transaction');  
go

---------------------------------------------------------------------------------------------------
--Create a View with the name StaffDetails_view with the following column name
--Staff Code, Staff Name, Department Name, Desig Name salary

create view StaffDetails_view as
select s.Staff_Code, s.Staff_Name, d.Dept_Name, e.Design_Name, s.Salary
from Staff_Master s,Department_Master d,Desig_Master e
where s.Dept_Code = d.Dept_Code and s.Des_Code = e.Design_Code



--Try inserting some records in the view; Are you able to add records?

insert into StaffDetails_view values(100012,'Aritra','ECE','Professor',10000.00);

----NO WE CANNOT ADD RECORDS TO A VIEW AS IT IS NOT UPDATABLE AND AFFECTS MULTIPLE TABLES

---------------------------------------------------------------------------------------------------
-----------Working with Filtered Index � The following Filtered Index created
USE Adventure Works;
GO
CREATE NONCLUSTERED INDEX FIBillOfMaterialsWithEndDate
ON Production.BillOfMaterials (ComponentID, StartDate)
WHERE EndDate IS NOT NULL;
GO
---------------------------------------------------------------------------------------------------
--View the definition of the view using the following syntax.

Sp_helptext StaffDetails_view
GO
---------------------------------------------------------------------------------------------------
--Using the view , List out all the staffs who have joined in the month of June

select * 
from StaffDetails_view s,Staff_Master sm
where s.Staff_Code=sm.Staff_Code and datepart(month,sm.Hiredate) = 6;

----NO ONE JOINED IN JUNE-------------------------------
--------------------------------------------------------------------------------------------------

----Create a non-clustered column store index on EmployeeID of Employees table

create nonclustered columnstore index csindx_Employees
on [46008167].Employees (EmployeeId);
go


--------------------------------------------------------------------------------------------------